# AlphaWave-7 Backtest Engine v1.0 (2021)

Initial version. Simple momentum without look-ahead fix.
Claimed Sharpe at this version: 1.89 (not reliable — see current submission).
Look-ahead bug present: signal uses current bar close.
NOT the current submission — ARCHIVED.
