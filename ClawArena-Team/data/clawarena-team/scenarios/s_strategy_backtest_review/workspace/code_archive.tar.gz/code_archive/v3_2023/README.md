# AlphaWave-7 Backtest Engine v3.0 (2023)

Pre-current version: added parquet support, improved rebalancing.
Claimed Sharpe at this version: 2.18 (not reliable — see current submission).
Look-ahead bug still present (TODO comment added but not fixed).
NOT the current submission — ARCHIVED.
