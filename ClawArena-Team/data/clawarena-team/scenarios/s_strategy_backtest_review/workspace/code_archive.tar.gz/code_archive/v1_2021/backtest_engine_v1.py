"""backtest_engine_v1.py — AlphaWave-7 v1.0 (ARCHIVED 2021).

Simple momentum backtest, initial version.
Claimed Sharpe 1.89 — computed with look-ahead bias present.
NOT the current version.
"""
import pandas as pd
import numpy as np

def run_backtest_v1(prices_csv: str) -> float:
    # v1: load CSV, compute simple 12-month momentum
    df = pd.read_csv(prices_csv, index_col=0, parse_dates=True)
    momentum = df / df.shift(252) - 1
    # BUG: no timestamp alignment correction
    signal = momentum  # look-ahead: uses current close
    returns = df.pct_change()
    port_ret = signal.shift(1).clip(-1, 1) * returns
    sharpe = port_ret.mean().mean() / port_ret.std().mean() * np.sqrt(252)
    return float(sharpe)

# Note: Sharpe 1.89 was the result of this version.
# This is STALE — do not cite in current risk review.
