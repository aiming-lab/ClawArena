"""backtest_engine_v3.py — AlphaWave-7 v3.0 (ARCHIVED 2023).

Added parquet data support. Look-ahead bug identified but not yet fixed.
Claimed Sharpe 2.18 — computed with look-ahead bias.
NOT the current version.
"""
import pandas as pd
import numpy as np

def run_backtest_v3(parquet_path: str) -> dict:
    df = pd.read_parquet(parquet_path)
    prices = df.pivot_table(index='date', columns='symbol', values='close')
    momentum = prices.shift(21) / prices.shift(252) - 1
    # TODO(elena): Fix look-ahead — signal should use prices.shift(1)
    signal = momentum  # BUG: look-ahead still present
    returns = prices.pct_change()
    port_ret = signal.clip(-1, 1) * returns
    sharpe = port_ret.stack().mean() / port_ret.stack().std() * np.sqrt(252)
    mdd = (port_ret.mean(axis=1).cumsum() - port_ret.mean(axis=1).cumsum().cummax()).min()
    return {'sharpe': float(sharpe), 'max_drawdown': float(mdd)}

# Note: Sharpe 2.18 was the result of this version.
# This is STALE — do not cite in current risk review.
# The current (v4) submission claims 2.31 (with look-ahead bug still present).
