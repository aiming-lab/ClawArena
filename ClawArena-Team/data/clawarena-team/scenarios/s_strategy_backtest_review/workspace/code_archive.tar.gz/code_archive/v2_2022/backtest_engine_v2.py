"""backtest_engine_v2.py — AlphaWave-7 v2.1 (ARCHIVED 2022).

Improved transaction cost model. Look-ahead bug still present.
Claimed Sharpe 2.05 — computed with look-ahead bias.
NOT the current version.
"""
import pandas as pd
import numpy as np

COMMISSION_BPS = 5.0
SLIPPAGE_BPS = 3.0

def run_backtest_v2(prices_csv: str) -> float:
    df = pd.read_csv(prices_csv, index_col=0, parse_dates=True)
    momentum = df.shift(21) / df.shift(252) - 1
    # BUG: signal still uses current close (look-ahead)
    signal = momentum  # should be momentum.shift(1)
    returns = df.pct_change()
    tc = (COMMISSION_BPS + SLIPPAGE_BPS) / 10000
    port_ret = signal.clip(-1, 1) * returns - tc
    sharpe = port_ret.mean().mean() / port_ret.std().mean() * np.sqrt(252)
    return float(sharpe)

# Note: Sharpe 2.05 was the result of this version.
# This is STALE — do not cite in current risk review.
