# code_archive — AlphaWave-7 Historical Code Versions

This archive contains historical backtest engine versions for audit purposes.
Extract with: tar -xzf code_archive.tar.gz

| Directory | Code Version | Notes |
|---|---|---|
| v1_2021/ | v1.0.0 | Initial version |
| v2_2022/ | v2.1.0 | TC model improvement |
| v3_2023/ | v3.0.2 | Parquet support |

The CURRENT submission is v4.1.0 (in backtest_code/). These archived
versions are retained for historical comparison only.
