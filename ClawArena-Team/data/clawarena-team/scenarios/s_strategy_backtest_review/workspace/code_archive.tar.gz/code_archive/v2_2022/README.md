# AlphaWave-7 Backtest Engine v2.1 (2022)

Partial update: improved transaction cost model, no look-ahead fix yet.
Claimed Sharpe at this version: 2.05 (not reliable — see current submission).
Look-ahead bug still present.
NOT the current submission — ARCHIVED.
