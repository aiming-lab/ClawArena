# vendor_snapshot/

This archive contains a snapshot of all vendored dependencies for MASE v0.9.0-rc1.

## Contents

- `Cargo.lock` — Rust dependency lock file (confirmed lib-tinypath 1.4.2)
- `package-lock.json` — JavaScript dependency lock file (confirms colorz 2.3.1)
- `jars/` — Maven artifact manifests for Java bridge dependencies
- `certs/` — Build signing certificate placeholders

## Usage

Extract with:
    tar -xzf vendor_snapshot.tar.gz

Then inspect Cargo.lock and package-lock.json for dependency versions.
Cross-reference with sbom/ and cve_db/ for CVE exposure.
