Evidence Bundle — NorthWind Apparel Chargeback Case CB-2026-04-00291

Contents:
  delivery_proof_front.png  — FedEx Proof of Delivery photo (VLM required)
  delivery_proof_label.png  — Package shipping label
  payment_gateway.log       — Payment gateway event log

IMPORTANT: Extract with `unzip evidence_bundle.zip` before reading.
The PNG files require a VLM (vision-capable) subagent to OCR the
delivery timestamp and signature fields.
