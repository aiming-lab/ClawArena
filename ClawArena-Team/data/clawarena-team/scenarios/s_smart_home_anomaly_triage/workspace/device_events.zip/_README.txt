# device_events.zip — Device Event Archive

This archive contains 8 .ndjson device event streams.
Unzip with: unzip device_events.zip

| File | Contents |
|------|----------|
| camera_events.ndjson | Camera motion / face-detection events |
| sensor_events.ndjson | Humidity, temperature, smoke readings |
| gateway_events.ndjson | NAT/ARP/DHCP events (contains unknown device MAC) |
| lock_events.ndjson | Smart lock arm/disarm events |
| misc_device_events.ndjson | Thermostat, lights, presence events |
| climate_events.ndjson | HVAC and climate system events |
| presence_events.ndjson | Occupant presence detection events |
| firmware_events.ndjson | Device firmware and OTA events |

KEY ANCHORS (zip contents):
  camera_events.ndjson: cam_basement_03 face_detected at 02:14:07
  sensor_events.ndjson: humidity_basement_01 spike to 94% at 02:13:50
  gateway_events.ndjson: unknown device MAC a4:cf:12:8e:7b:3d at 02:13:58
