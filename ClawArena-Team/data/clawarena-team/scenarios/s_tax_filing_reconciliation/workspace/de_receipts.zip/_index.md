# de_receipts.zip — Contents

This archive contains German receipt documents for TY 2026.

Files:
  Rechnung_2026_01.pdf  — January 2026 invoice (Betrag: 1.535,00 EUR)
  Rechnung_2026_02.pdf  — February 2026 invoice
  ... (12 monthly invoices total)
  Rechnung_2026_12.pdf  — December 2026 invoice
  finanzamt_notice_2026.pdf — Bundeszentralamt für Steuern notice

Each invoice shows:
  Betrag / 金额: 1.535,00 EUR / 1,535.00 欧元

Finanzamt notice issued by: Bundeszentralamt für Steuern
